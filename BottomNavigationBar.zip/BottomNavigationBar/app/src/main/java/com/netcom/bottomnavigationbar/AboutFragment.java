package com.netcom.bottomnavigationbar;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;

public class AboutFragment extends Fragment {

    TabLayout tabLayoutAbout ;
    ViewPager viewPager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_about, container, false);
        tabLayoutAbout = view.findViewById(R.id.tabLayoutId);
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Maths"));
        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Physics"));
//        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Chemistry"));
//        tabLayoutAbout.addTab(tabLayoutAbout.newTab().setText("Biology"));
        tabLayoutAbout.setTabGravity(TabLayout.GRAVITY_FILL);
        viewPager = view.findViewById(R.id.aboutContainerId);


//        MyAdapter adapter = new MyAdapter(this,getFragmentManager() ,AboutFragment.class, tabLayoutAbout.getTabCount());

        tabLayoutAbout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        // Inflate the layout for this fragment
        return view;
    }
}