package com.netcom.bottomnavigationbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize And Assign Variable
        bottomNavigationView = findViewById(R.id.bottomNavigationViewId);

        //Set Home Selected
//        bottomNavigationView.setSelectedItemId(R.id.home_nav);
        setTitle("Home");
       getSupportFragmentManager().beginTransaction().replace(R.id.container, new HomeFragment()).commit();

        //Add Item Selection
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                switch (item.getItemId()) {
                    case R.id.home_nav: {
                        fragment = new HomeFragment();
                        setTitle("Home");
                        break;
                    }
                    case R.id.dash_nav: {
                        fragment = new DashFragment();
                        setTitle("Dashboard");
                        break;
                    }
                    case R.id.about_nav: {
                        fragment = new AboutFragment();
                        setTitle("All Subjest");
                        break;
                    }
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.container, fragment).commit();
                return true;
            }
        });
    }
}