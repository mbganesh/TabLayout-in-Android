package com.netcom.bottomnavigationbar;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class MyAdapter extends FragmentPagerAdapter {

    private Context context;
    int totTabs;

    public MyAdapter(@NonNull FragmentManager fm, int behavior, Context context, int totTabs) {
        super(fm, behavior);
        this.context = context;
        this.totTabs = totTabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                MathsFragment mathsFragment = new MathsFragment();
                return mathsFragment;
            case 1:
                PhysicsFragment physicsFragment = new PhysicsFragment();
                return physicsFragment;
            default:
                return null;
        }

    }
    @Override
    public int getCount() {
        return totTabs;
    }
}
